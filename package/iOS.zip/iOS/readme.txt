iOS.zip - download imgs for app store

v1.1.0

This is <<iPhone>> package.

---------- icon size list ----------

【Common】
・App icon for the App Store - 1024x1024
・Launch image (4inch) - 640x1136
・Launch image (3.5inch) - 640x960
・Launch image (3.5inch/Not Retina) - 320x480


【iOS 7】
・App icon - 120x120
・Spotlight Search result icon - 80x80
・Setting icon - 58x58


【iOS 6】
・App icon - 114x114
・App icon (Not Retina) - 57x57
・Spotlight Search result & setting icon - 58x58
・Spotlight Search result & setting icon (Not Retina) - 29x29

-------------------------------------


ご利用いただきありがとうございます。
ファイルサイズの間違い、不足等がございましたら 早急に対応しますので
GitHub (https://github.com/himaratsu/ioszip/issues)、または
Twitter (https://twitter.com/himara2) までご連絡ください。

ご意見ご要望も上記連絡先にて受け付けておりますのでお気軽にお願いします;)


--
http://ioszip.mashroom.in/
2013 @himara2 All rights reserved.


